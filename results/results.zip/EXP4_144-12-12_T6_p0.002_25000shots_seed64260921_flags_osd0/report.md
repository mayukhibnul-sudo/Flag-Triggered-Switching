# Experiment 4 — [[144, 12, 12]], T=6, p=0.002, 25000 shots

Data file: `EXP4_144-12-12_T6_p0.002_25000shots_seed64260921_flags_osd0.json`  
Exported: 2026-09-25T12:13:42

## Table: metrics

[metrics.csv](metrics.csv) — 5 rows

| code | rounds | p | shots | seed | use_flags | osd_order | workers | policy | failures | ler | ci_low | ci_high | escalation_rate | silent_failures | unconverged_failures | escalated_failures | work_mean | work_p99 | time_p50_us | time_p99_us |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| [[144, 12, 12]] | 6 | 0.002 | 25000 | 64260921 | True | 0 | 12 | never | 20856 | 0.8342 | 0.8296 | 0.8388 | 0 | 0 | 20856 | 0 | 76.53 | 142 | 6.607e+04 | 1.524e+05 |
| [[144, 12, 12]] | 6 | 0.002 | 25000 | 64260921 | True | 0 | 12 | always | 198 | 0.00792 | 0.006894 | 0.009097 | 1 | 0 | 0 | 198 | 19.9 | 20 | 6.063e+05 | 1.346e+06 |
| [[144, 12, 12]] | 6 | 0.002 | 25000 | 64260921 | True | 0 | 12 | primary_fail | 198 | 0.00792 | 0.006894 | 0.009097 | 0.9642 | 0 | 0 | 198 | 95.75 | 162 | 6.682e+05 | 1.449e+06 |
| [[144, 12, 12]] | 6 | 0.002 | 25000 | 64260921 | True | 0 | 12 | flag | 198 | 0.00792 | 0.006894 | 0.009097 | 0.9984 | 0 | 0 | 198 | 20.47 | 46 | 6.068e+05 | 1.346e+06 |
| [[144, 12, 12]] | 6 | 0.002 | 25000 | 64260921 | True | 0 | 12 | flag_or_fail | 198 | 0.00792 | 0.006894 | 0.009097 | 0.9984 | 0 | 0 | 198 | 20.47 | 46 | 6.068e+05 | 1.346e+06 |

## Figure: ablation

![ablation](ablation.png)  
Vector version: [ablation.pdf](ablation.pdf)

## Figure: outcomes

![outcomes](outcomes.png)  
Vector version: [outcomes.pdf](outcomes.pdf)

## Figure: tradeoff

![tradeoff](tradeoff.png)  
Vector version: [tradeoff.pdf](tradeoff.pdf)

## Figure: latency

![latency](latency.png)  
Vector version: [latency.pdf](latency.pdf)
