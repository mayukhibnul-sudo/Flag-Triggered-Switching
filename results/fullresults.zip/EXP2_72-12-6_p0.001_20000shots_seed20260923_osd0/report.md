# Flag trade-off study — [[72, 12, 6]], p = 0.001

Data file: `EXP2_72-12-6_p0.001_20000shots_seed20260923_osd0.json`  
Exported: 2026-09-26T01:45:09

**Flags pay up to T\* ≈ 704** and cost accuracy beyond it (weighted fit, slope +0.000 per round).

## Table: points

[points.csv](points.csv) — 4 rows

| rounds | shots | unflagged failures | flagged, blind failures | flagged, sighted failures | unflagged LER | flagged, blind LER | flagged, sighted LER | ratio_sighted | ratio_blind | flagged_fraction | mean_flags | blind_only_fail | sighted_only_fail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6 | 20000 | 213 | 300 | 149 | 0.01065 | 0.015 | 0.00745 | 0.6995 | 1.408 | 0.6751 | 1.117 | 199 | 48 |
| 12 | 20000 | 430 | 653 | 340 | 0.0215 | 0.03265 | 0.017 | 0.7907 | 1.519 | 0.8955 | 2.226 | 443 | 130 |
| 18 | 20000 | 651 | 956 | 517 | 0.03255 | 0.0478 | 0.02585 | 0.7942 | 1.469 | 0.9658 | 3.351 | 656 | 217 |
| 24 | 20000 | 873 | 1246 | 655 | 0.04365 | 0.0623 | 0.03275 | 0.7503 | 1.427 | 0.9895 | 4.471 | 855 | 264 |

## Table: overhead

[overhead.csv](overhead.csv) — 4 rows

| rounds | qubits_unflagged | qubits_flagged | qubit_overhead | gate_overhead | fault_overhead | lambda_unflagged | lambda_flagged |
|---|---|---|---|---|---|---|---|
| 6 | 144 | 180 | 0.25 | 0.1667 | 0.08182 | 3.488 | 4.322 |
| 12 | 144 | 180 | 0.25 | 0.1667 | 0.07725 | 6.885 | 8.554 |
| 18 | 144 | 180 | 0.25 | 0.1667 | 0.07584 | 10.28 | 12.79 |
| 24 | 144 | 180 | 0.25 | 0.1667 | 0.07516 | 13.68 | 17.02 |

## Figure: three_arms_vs_rounds

![three_arms_vs_rounds](three_arms_vs_rounds.png)  
Vector version: [three_arms_vs_rounds.pdf](three_arms_vs_rounds.pdf)
