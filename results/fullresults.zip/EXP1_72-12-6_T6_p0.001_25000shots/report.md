# Experiment 1 validation — [[72, 12, 6]], T=6, p=0.001

Data file: `EXP1_72-12-6_T6_p0.001_25000shots.json`  
Exported: 2026-09-26T02:00:20

Literature source: Pakhunov (2026), Table II, [[72,12,6]], p=1e-3, T=12

## Table: checks

[checks.csv](checks.csv) — 4 rows

| check | value | detail |
|---|---|---|
| Check 1: fault-model density | 10.0× | 15,840 faults vs 1,584 from n(wT + T/2 + 1) |
| Check 2: reproduces literature | no | ours 0.599 [0.593, 0.605] vs 0.935 (Pakhunov (2026), Table II, [[72,12,6]], p=1e-3, T=12) |
| Check 3: accuracy cost of flags | flags improve accuracy | LER 7.76e-03 with flags vs 1.19e-02 without; +1,296 faults, +216 detectors; flags fire on 67.6% of shots |
| silent failures (weak decoder) | 0 flagged / 0 unflagged | the only failures a flag trigger could ever catch |

## Figure: validation

![validation](validation.png)  
Vector version: [validation.pdf](validation.pdf)
