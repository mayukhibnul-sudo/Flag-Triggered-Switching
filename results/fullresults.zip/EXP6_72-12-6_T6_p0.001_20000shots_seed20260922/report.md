# Experiment 6 decoder zoo — 20,000 shots

Data file: `EXP6_72-12-6_T6_p0.001_20000shots_seed20260922.npz`  
Exported: 2026-09-26T02:58:42

Verdict counts: not viable: 9, viable: cost: 7

## Table: verdicts

[verdicts.csv](verdicts.csv) — 16 rows

| weak | strong | verdict | verdict_accuracy | verdict_cost | headroom | min_detectable_discordant | pf_failures | pf_escalation | pf_cost_us | always_failures | best_accuracy_rule | best_cost_rule | best_saving | cost_ratio |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| peel | OSD-0 | not viable | impossible: no headroom | not viable | 0 | 6 | 148 | 0.4032 | 1.155e+05 | 160 | None | None | 0 | 0.1666 |
| peel | OSD-CS4 | not viable | impossible: no headroom | not viable | 0 | 6 | 48 | 0.4032 | 7.012e+05 | 49 | None | None | 0 | 0.01014 |
| peel | LSD-0 | not viable | impossible: no headroom | not viable | 0 | 6 | 152 | 0.4032 | 9.197e+04 | 164 | None | None | 0 | 0.2986 |
| peel | LSD-CS4 | not viable | impossible: no headroom | not viable | 0 | 6 | 132 | 0.4032 | 1.026e+05 | 142 | None | None | 0 | 0.2726 |
| BP-ms-10 | OSD-0 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 160 | 0.7192 | 2.558e+05 | 160 | None | flag>=1 | 0.2137 | 0.7291 |
| BP-ms-10 | OSD-CS4 | not viable | impossible: no headroom | not viable | 0 | 6 | 49 | 0.7192 | 1.361e+06 | 49 | None | None | 0.04237 | 0.04438 |
| BP-ms-10 | LSD-0 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 164 | 0.7192 | 2.096e+05 | 164 | None | flag>=1 | 0.2681 | 1.307 |
| BP-ms-10 | LSD-CS4 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 142 | 0.7192 | 2.285e+05 | 142 | None | flag>=1 | 0.2431 | 1.193 |
| BP-ms-30 | OSD-0 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 160 | 0.6392 | 3.609e+05 | 160 | None | flag>=1 | 0.3753 | 1.102 |
| BP-ms-30 | OSD-CS4 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 49 | 0.6392 | 1.471e+06 | 49 | None | flag>=1 | 0.09656 | 0.06705 |
| BP-ms-30 | LSD-0 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 164 | 0.6392 | 3.172e+05 | 164 | None | flag>=1 | 0.4375 | 1.975 |
| BP-ms-30 | LSD-CS4 | viable: cost | impossible: no headroom | viable: cost | 0 | 6 | 142 | 0.6392 | 3.351e+05 | 142 | None | flag>=1 | 0.41 | 1.803 |
| BP-ps-30 | OSD-0 | not viable | impossible: no headroom | not viable | 0 | 6 | 154 | 0.5303 | 3.881e+05 | 160 | None | None | 0 | 2.298 |
| BP-ps-30 | OSD-CS4 | not viable | impossible: no headroom | not viable | 0 | 6 | 48 | 0.5303 | 1.211e+06 | 49 | None | None | 0.01264 | 0.1399 |
| BP-ps-30 | LSD-0 | not viable | impossible: no headroom | not viable | 0 | 6 | 158 | 0.5303 | 3.546e+05 | 164 | None | None | 0 | 4.12 |
| BP-ps-30 | LSD-CS4 | not viable | impossible: no headroom | not viable | 0 | 6 | 138 | 0.5303 | 3.685e+05 | 142 | None | None | 0 | 3.761 |

## Table: weak_decoders

[weak_decoders.csv](weak_decoders.csv) — 4 rows

| weak | converged | silent | silent_rate | silent_rate_upper | silent_on_flagged | median_time_us |
|---|---|---|---|---|---|---|
| peel | 11936 | 0 | 0 | 0.0003217 | 0 | 1.775e+04 |
| BP-ms-10 | 5615 | 0 | 0 | 0.0006837 | 0 | 7.768e+04 |
| BP-ms-30 | 7216 | 0 | 0 | 0.0005321 | 0 | 1.174e+05 |
| BP-ps-30 | 9394 | 0 | 0 | 0.0004088 | 0 | 2.449e+05 |

## Table: all_rules

[all_rules.csv](all_rules.csv) — 128 rows

## Table: flag_diagnostics

[flag_diagnostics.csv](flag_diagnostics.csv) — 8 rows

| decoder | flagged_fraction | error_rate_flagged | error_rate_unflagged | risk_ratio | mutual_information_bits | share_of_failures_on_flagged |
|---|---|---|---|---|---|---|
| peel | 0.6711 | 0.3326 | 0.1474 | 2.256 | 0.02967 | 0.8215 |
| BP-ms-10 | 0.6711 | 0.5515 | 0.3228 | 1.708 | 0.03397 | 0.777 |
| BP-ms-30 | 0.6711 | 0.4909 | 0.268 | 1.832 | 0.03357 | 0.7889 |
| BP-ps-30 | 0.6711 | 0.4152 | 0.1847 | 2.248 | 0.0401 | 0.821 |
| OSD-0 | 0.6711 | 0.01133 | 0.001216 | 9.314 | 0.002741 | 0.95 |
| OSD-CS4 | 0.6711 | 0.003651 | 0 | inf | 0.001412 | 1 |
| LSD-0 | 0.6711 | 0.01162 | 0.001216 | 9.559 | 0.002842 | 0.9512 |
| LSD-CS4 | 0.6711 | 0.009984 | 0.001216 | 8.211 | 0.002289 | 0.9437 |

## Table: strong_ceiling

[strong_ceiling.csv](strong_ceiling.csv) — 12 rows

| decoder | compared_with | failures | fixed_by_other | broken_by_other |
|---|---|---|---|---|
| OSD-0 | OSD-CS4 | 160 | 116 | 5 |
| OSD-0 | LSD-0 | 160 | 0 | 4 |
| OSD-0 | LSD-CS4 | 160 | 23 | 5 |
| OSD-CS4 | OSD-0 | 49 | 5 | 116 |
| OSD-CS4 | LSD-0 | 49 | 5 | 120 |
| OSD-CS4 | LSD-CS4 | 49 | 7 | 100 |
| LSD-0 | OSD-0 | 164 | 4 | 0 |
| LSD-0 | OSD-CS4 | 164 | 120 | 5 |
| LSD-0 | LSD-CS4 | 164 | 26 | 4 |
| LSD-CS4 | OSD-0 | 142 | 5 | 23 |
| LSD-CS4 | OSD-CS4 | 142 | 100 | 7 |
| LSD-CS4 | LSD-0 | 142 | 4 | 26 |

## Figure: verdicts

![verdicts](verdicts.png)  
Vector version: [verdicts.pdf](verdicts.pdf)

## Figure: silent_failures

![silent_failures](silent_failures.png)  
Vector version: [silent_failures.pdf](silent_failures.pdf)

## Figure: breakeven

![breakeven](breakeven.png)  
Vector version: [breakeven.pdf](breakeven.pdf)

## Figure: tradeoffs

![tradeoffs](tradeoffs.png)  
Vector version: [tradeoffs.pdf](tradeoffs.pdf)
