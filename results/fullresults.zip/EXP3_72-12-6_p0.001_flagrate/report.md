# Experiment 3 flag rate vs rounds — [[72, 12, 6]], p=0.001

Data file: `EXP3_72-12-6_p0.001_flagrate.json`  
Exported: 2026-09-26T02:00:20

A trigger that fires on nearly every shot cannot discriminate; this is the mechanism behind a null result for flag triggering.

## Table: flag_rate

[flag_rate.csv](flag_rate.csv) — 5 rows

| rounds | flag_detectors | fraction_any_flag | mean_flags_per_shot |
|---|---|---|---|
| 3 | 108 | 0.4455 | 0.5825 |
| 6 | 216 | 0.674 | 1.127 |
| 12 | 432 | 0.8905 | 2.285 |
| 18 | 648 | 0.967 | 3.389 |
| 24 | 864 | 0.9885 | 4.494 |

## Figure: flag_rate_vs_rounds

![flag_rate_vs_rounds](flag_rate_vs_rounds.png)  
Vector version: [flag_rate_vs_rounds.pdf](flag_rate_vs_rounds.pdf)
