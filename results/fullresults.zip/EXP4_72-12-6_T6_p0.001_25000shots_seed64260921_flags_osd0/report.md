# Experiment 4 — [[72, 12, 6]], T=6, p=0.001, 25000 shots

Data file: `EXP4_72-12-6_T6_p0.001_25000shots_seed64260921_flags_osd0.json`  
Exported: 2026-09-25T19:09:27

## Table: metrics

[metrics.csv](metrics.csv) — 5 rows

| code | rounds | p | shots | seed | use_flags | osd_order | workers | policy | failures | ler | ci_low | ci_high | escalation_rate | silent_failures | unconverged_failures | escalated_failures | work_mean | work_p99 | time_p50_us | time_p99_us |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| [[72, 12, 6]] | 6 | 0.001 | 25000 | 64260921 | True | 0 | 12 | never | 6785 | 0.2714 | 0.2659 | 0.2769 | 0 | 0 | 6785 | 0 | 17.6 | 52 | 1.495e+04 | 6.634e+04 |
| [[72, 12, 6]] | 6 | 0.001 | 25000 | 64260921 | True | 0 | 12 | always | 194 | 0.00776 | 0.006745 | 0.008926 | 1 | 0 | 0 | 194 | 15.25 | 20 | 1.551e+05 | 3.94e+05 |
| [[72, 12, 6]] | 6 | 0.001 | 25000 | 64260921 | True | 0 | 12 | primary_fail | 185 | 0.0074 | 0.006411 | 0.008541 | 0.4006 | 0 | 0 | 185 | 25.02 | 72 | 1.9e+04 | 4.268e+05 |
| [[72, 12, 6]] | 6 | 0.001 | 25000 | 64260921 | True | 0 | 12 | flag | 192 | 0.00768 | 0.006671 | 0.00884 | 0.7596 | 0 | 0 | 192 | 16.45 | 50 | 1.021e+05 | 3.971e+05 |
| [[72, 12, 6]] | 6 | 0.001 | 25000 | 64260921 | True | 0 | 12 | flag_or_fail | 192 | 0.00768 | 0.006671 | 0.00884 | 0.7596 | 0 | 0 | 192 | 16.45 | 50 | 1.021e+05 | 3.971e+05 |

## Figure: ablation

![ablation](ablation.png)  
Vector version: [ablation.pdf](ablation.pdf)

## Figure: outcomes

![outcomes](outcomes.png)  
Vector version: [outcomes.pdf](outcomes.pdf)

## Figure: tradeoff

![tradeoff](tradeoff.png)  
Vector version: [tradeoff.pdf](tradeoff.pdf)

## Figure: latency

![latency](latency.png)  
Vector version: [latency.pdf](latency.pdf)
