import dataclasses, time, numpy as np, scipy.sparse as sp
from decoderSwitch import app
t = time.time()
_, nb = app.run()
assert nb["core_ready"], "tests fail"
print(f"notebook ran, all tests pass ({time.time()-t:.0f}s)")
cfg = dataclasses.replace(nb["ExperimentConfig"](), shots=25_000)
code = nb["code_from_key"](cfg.code)
circ = nb["build_memory_circuit"](code, cfg.rounds, cfg.p, use_flags=cfg.use_flags)
H, L, pr = nb["dem_to_matrices"](circ.detector_error_model(decompose_errors=False))
mask = nb["flag_detector_mask"](code, cfg.rounds, cfg.use_flags, circ.num_detectors)
det, obs = circ.compile_detector_sampler(seed=cfg.seed).sample(cfg.shots, separate_observables=True)
mx = code.hx.shape[0]
np.savez_compressed("shots.npz", det=det.astype(np.uint8), obs=obs.astype(np.uint8), mask=mask,
                    mx=mx, rounds=cfg.rounds)
sp.save_npz("H.npz", H.tocsr()); sp.save_npz("L.npz", L.tocsr()); np.save("priors.npy", pr)
open("config.txt", "w").write(repr(cfg))
print(cfg); print(f"H {H.shape}, flag detectors {int(mask.sum())}, shots saved: {det.shape}")
