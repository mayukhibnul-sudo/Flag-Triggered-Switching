import numpy as np, scipy.sparse as sp
exec(open("worker.py").read().split("H = sp.load_npz")[0])          # loads the notebook's classes
exec(open("derive.py").read())
(SwitchPolicy,) = run_cell("class SwitchPolicy:", DecodeResult=DecodeResult, np=np)
TRIGGERS = ("never", "always", "primary_fail", "flag", "flag_or_fail")
H = sp.load_npz("H.npz").tocsr(); L = sp.load_npz("L.npz").tocsr(); pr = np.load("priors.npy")
peel, osd = PeelingDecoder(H, pr), BpOsdDecoder(H, pr, osd_order=0)
N = 300; mism = 0
for t in TRIGGERS:
    pol = SwitchPolicy(peel, osd, t, mask)
    for i in range(N):
        r = pol.decode(det[i]); f = bool(((L @ r.correction) % 2 != obs[i]).any())
        mism += (r.escalated != POL[t]["esc"][i]) + (f != POL[t]["fail"][i])
print(f"cross-check on {N} shots x {len(TRIGGERS)} policies: {mism} mismatches")
