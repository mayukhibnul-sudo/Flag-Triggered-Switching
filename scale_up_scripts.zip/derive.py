import glob, numpy as np
d = np.load("shots.npz"); det, obs, mask = d["det"], d["obs"], d["mask"]
mx, T = int(d["mx"]), int(d["rounds"])
parts = sorted(glob.glob("chunks/*.npz"))
bounds = [tuple(map(int, p.split("/")[-1][:-4].split("_"))) for p in parts]
assert bounds[0][0] == 0 and bounds[-1][1] == len(det) and all(a[1] == b[0] for a, b in zip(bounds, bounds[1:]))
R = {k: np.concatenate([np.load(p)[k] for p in parts]) for k in np.load(parts[0]).files}
flag_bits = det[:, mask].astype(bool)                       # (shots, mx*T), grouped by round
n_flags = flag_bits.sum(1)
flag_rounds = flag_bits.reshape(len(det), T, mx).any(2).sum(1)
flagged = n_flags > 0

def policy(esc):
    esc = np.asarray(esc, bool)
    fail = np.where(esc, R["osd_fail"], R["peel_fail"])
    return dict(esc=esc, fail=fail,
                silent=~esc & R["peel_conv"] & R["peel_fail"],
                unconv=~esc & ~R["peel_conv"] & R["peel_fail"],
                us=np.where(esc & flagged_skip(esc), 0, R["peel_us"]) + np.where(esc, R["osd_us"], 0))
def flagged_skip(esc): return np.zeros_like(esc)             # placeholder, replaced per policy below

never = dict(esc=np.zeros(len(det), bool), fail=R["peel_fail"], silent=R["peel_conv"] & R["peel_fail"],
             unconv=~R["peel_conv"] & R["peel_fail"], us=R["peel_us"])
always = dict(esc=np.ones(len(det), bool), fail=R["osd_fail"], silent=np.zeros(len(det), bool),
              unconv=np.zeros(len(det), bool), us=R["osd_us"])
def switched(pre, fallback=True):
    """pre: shots escalated BEFORE the primary runs (flag); fallback: also escalate on primary failure."""
    esc = pre | (~R["peel_conv"] if fallback else False)
    fail = np.where(esc, R["osd_fail"], R["peel_fail"])
    us = np.where(pre, 0, R["peel_us"]) + np.where(esc, R["osd_us"], 0)
    return dict(esc=esc, fail=fail, silent=~esc & R["peel_conv"] & R["peel_fail"],
                unconv=~esc & ~R["peel_conv"] & R["peel_fail"], us=us)
none = np.zeros(len(det), bool)
POL = {"never": never, "always": always, "primary_fail": switched(none),
       "flag": switched(flagged), "flag_or_fail": switched(flagged)}
