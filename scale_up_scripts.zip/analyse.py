import numpy as np
from math import comb
exec(open("derive.py").read())
N = len(det); z = 1.96
def wilson(k, n):
    ph = k / n; d = 1 + z*z/n; c = (ph + z*z/(2*n)) / d; h = z*np.sqrt(ph*(1-ph)/n + z*z/(4*n*n)) / d
    return ph, (0.0 if k == 0 else c - h), (1.0 if k == n else c + h)
def mcnemar(a, b):
    """Exact two-sided paired test on the shots where exactly one of the two policies failed."""
    x, y = int((a & ~b).sum()), int((~a & b).sum()); n = x + y
    if n == 0: return x, y, 1.0
    k = min(x, y); p = min(1.0, 2 * sum(comb(n, i) for i in range(k + 1)) / 2**n)
    return x, y, p

print(f"== E1 at scale: {N} paired shots, [[72,12,6]], T=6, p=1e-3, flags on, OSD-0 ==\n")
print(f"{'policy':14s} {'fail':>5s} {'LER':>8s}  {'95% CI':19s} {'escalated':>9s} {'silent':>6s} {'unconv':>6s}")
for n, P in POL.items():
    k = int(P["fail"].sum()); ph, lo, hi = wilson(k, N)
    print(f"{n:14s} {k:5d} {ph:8.5f}  [{lo:.5f}, {hi:.5f}] {P['esc'].mean():9.1%} {int(P['silent'].sum()):6d} {int(P['unconv'].sum()):6d}")

conv = R["peel_conv"]; silent = conv & R["peel_fail"]
k, n = int(silent.sum()), int(conv.sum()); ph, lo, hi = wilson(k, n)
print(f"\npeeling converged on {n} shots ({n/N:.1%}); silent failures among them: {k}  "
      f"(rate {ph:.2e}, 95% upper bound {hi:.2e})")
print(f"peeling unconverged: {int((~conv).sum())}; of those BP+OSD then failed on {int((~conv & R['osd_fail']).sum())}")
print(f"BP+OSD failures on shots where peeling converged correctly: {int((conv & ~R['peel_fail'] & R['osd_fail']).sum())}")

print("\npaired exact tests (x = only A fails, y = only B fails):")
for A, B in [("primary_fail", "always"), ("flag_or_fail", "always"), ("flag_or_fail", "primary_fail")]:
    x, y, p = mcnemar(POL[A]["fail"], POL[B]["fail"]); print(f"  {A:13s} vs {B:13s}: x={x}, y={y}, p={p:.3f}")

print(f"\nflags: fired on {flagged.mean():.1%} of shots; mean {n_flags.mean():.2f} flag bits per shot")
print("  distribution of flag bits fired:", {int(v): int((n_flags == v).sum()) for v in range(6)}, f"| >=6: {int((n_flags >= 6).sum())}")
print(f"  peeling fails to converge on {(~conv[flagged]).mean():.1%} of flagged vs {(~conv[~flagged]).mean():.1%} of unflagged shots")
print(f"  BP+OSD logical failure rate: flagged {R['osd_fail'][flagged].mean():.2e} vs unflagged {R['osd_fail'][~flagged].mean():.2e}")

print("\nexploratory sharper flag rules (escalate if rule fires, else fall back on primary failure):")
print(f"  {'rule':34s} {'escalated':>9s} {'fail':>5s} {'extra esc vs primary_fail':>26s}")
base = POL["primary_fail"]["esc"].mean()
rules = {f">= {k} flag bits": n_flags >= k for k in (1, 2, 3, 4)}
rules.update({f"flags in >= {k} rounds": flag_rounds >= k for k in (2, 3)})
for name, pre in rules.items():
    P = switched(pre); print(f"  {name:34s} {P['esc'].mean():9.1%} {int(P['fail'].sum()):5d} {P['esc'].mean() - base:+25.1%}")
P = switched(flagged, fallback=False)
print(f"  {'flag ONLY (no fallback)':34s} {P['esc'].mean():9.1%} {int(P['fail'].sum()):5d}   <- flag alone misses unconverged shots")
np.savez("derived.npz", **{f"{n}__{k}": v for n, P in POL.items() for k, v in P.items()})
