"""Decode shots [start, stop) with the notebook's own peeling and BP+OSD decoders."""
import ast, sys, time, os, numpy as np, scipy.sparse as sp
from dataclasses import dataclass, field

src = open("decoderSwitch.py").read(); tree = ast.parse(src)
cells = {n: ast.get_source_segment(src, n) for n in tree.body if isinstance(n, ast.FunctionDef)}
def run_cell(marker, **deps):
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and marker in ast.get_source_segment(src, n))
    node.decorator_list = []
    g = dict(deps); exec(compile(ast.Module(body=[node], type_ignores=[]), "decoderSwitch.py", "exec"), g)
    params = [a.arg for a in node.args.args]
    return g[node.name](*[deps[p] for p in params if p in deps])

(DecodeResult,) = run_cell("class DecodeResult:", dataclass=dataclass, np=np)
BpDecoder, BpLsdDecoder, BpOsdDecoder, PeelingDecoder = run_cell(
    "class PeelingDecoder:", DecodeResult=DecodeResult, np=np, sp=sp)

H = sp.load_npz("H.npz").tocsr(); L = sp.load_npz("L.npz").tocsr(); pr = np.load("priors.npy")
d = np.load("shots.npz"); det, obs = d["det"], d["obs"]
start, stop = int(sys.argv[1]), int(sys.argv[2])
peel, osd = PeelingDecoder(H, pr), BpOsdDecoder(H, pr, osd_order=0)
n = stop - start
out = {k: np.zeros(n, dt) for k, dt in [("peel_conv", bool), ("peel_fail", bool), ("peel_us", float),
       ("peel_work", np.int64), ("osd_fail", bool), ("osd_us", float), ("osd_work", np.int64),
       ("osd_bp_conv", bool)]}
t0 = time.time()
for i, s in enumerate(det[start:stop]):
    o = obs[start + i]
    a = time.perf_counter(); r = peel.decode(s); out["peel_us"][i] = (time.perf_counter() - a) * 1e6
    out["peel_conv"][i] = r.converged; out["peel_work"][i] = r.work
    out["peel_fail"][i] = bool(((L @ r.correction) % 2 != o).any())
    a = time.perf_counter(); r = osd.decode(s); out["osd_us"][i] = (time.perf_counter() - a) * 1e6
    out["osd_work"][i] = r.work; out["osd_bp_conv"][i] = r.work < 20 or bool(osd.dec.converge)
    out["osd_fail"][i] = bool(((L @ r.correction) % 2 != o).any())
os.makedirs("chunks", exist_ok=True)
np.savez(f"chunks/{start:06d}_{stop:06d}.npz", **out)
print(f"shots {start}-{stop}: {time.time()-t0:.0f}s ({1e3*(time.time()-t0)/n:.1f} ms/shot)")
